from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from app.models import Product, Order, OrderItem
from app import db

products_bp = Blueprint('products', __name__)

@products_bp.route('/products')
def product_list():
    products = Product.query.all()
    return render_template('products/list.html', products=products)

@products_bp.route('/product/<int:id>')
def product_detail(id):
    product = Product.query.get_or_404(id)
    return render_template('products/detail.html', product=product)

@products_bp.route('/cart/add/<int:product_id>')
@login_required
def add_to_cart(product_id):
    # Implementation for adding to cart
    flash('Product added to cart')
    return redirect(url_for('products.product_list'))